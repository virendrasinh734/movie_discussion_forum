# movie_discussion_forum
A web based movie discussion forum allowing users to discuss and rate moves, join different movie rooms and get movie recommendations, built using Django in the backend
